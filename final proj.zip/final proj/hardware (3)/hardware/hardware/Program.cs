﻿using System;
using System.Windows.Forms;

namespace hardware
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            using (LoginForm login = new LoginForm())
            {
                // Show login as a modal dialog
                if (login.ShowDialog() == DialogResult.OK)
                {
                    // Open Form1 only if login successful
                    Application.Run(new Form1());
                }
                else
                {
                    // Login canceled or failed
                    Application.Exit();
                }
            }
        }
    }
}