﻿using System;
using System.Windows.Forms;

namespace hardware
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();

            // Press ENTER to login
            this.AcceptButton = btnLogin;

            // Optional: prevent resizing
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user = txtUser.Text.Trim();
            string pass = txtPass.Text.Trim();

            // Replace these with your desired credentials
            if (user == "admin" && pass == "1234")
            {
                // Login successful
                this.DialogResult = DialogResult.OK; // This is key!
                this.Close(); // Close login form
            }
            else
            {
                MessageBox.Show("Invalid Username or Password!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Optional: prevent closing without login
            if (this.DialogResult != DialogResult.OK)
            {
                // User closed with X or canceled
                this.DialogResult = DialogResult.Cancel;
            }
        }
    }
}