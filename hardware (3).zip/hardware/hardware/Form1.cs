﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace hardware
{
    public partial class Form1 : Form
    {
        class Tool
        {
            public int Id { get; set; }
            public string Code { get; set; }
            public string Name { get; set; }
            public string Category { get; set; }
            public int Quantity { get; set; }
        }

        Dictionary<int, Tool> tools = new Dictionary<int, Tool>();

        public Form1()
        {
            InitializeComponent();
            LoadGrid();
        }

        void LoadGrid()
        {
            try
            {
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = tools.Values.ToList();

                progressBar1.Maximum = 100;
                progressBar1.Value = Math.Min(tools.Count * 10, 100);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Tool t = new Tool()
                {
                    Id = int.Parse(txtId.Text),
                    Code = txtCode.Text,
                    Name = txtName.Text,
                    Category = txtCategory.Text,
                    Quantity = int.Parse(txtQuantity.Text)
                };

                tools[t.Id] = t;
                LoadGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string keyword = txtSearch.Text.ToLower();

                var result = tools.Values
                    .Where(x =>
                        x.Name.ToLower().Contains(keyword) ||
                        x.Code.ToLower().Contains(keyword))
                    .ToList();

                dataGridView1.DataSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            try
            {
                string cat = txtFilter.Text.ToLower();

                var result = tools.Values
                    .Where(x => x.Category.ToLower().Contains(cat))
                    .ToList();

                dataGridView1.DataSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            try
            {
                var sorted = tools.Values
                    .OrderBy(x => x.Name)
                    .ToList();

                dataGridView1.DataSource = sorted;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog of = new OpenFileDialog();
                of.Filter = "Images|*.png;*.jpg";

                if (of.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = of.FileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}