﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Publico_Lood_Finals
{
    class Hardware
    {
        public string HardwareID { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Brand { get; set; }
        public int Quantity { get; set; }
        public string Status { get; set; }
        public string Location { get; set; }
    }
}