﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Publico_Lood_Finals
{
    public partial class Form1 : Form
    {
        Dictionary<string, Hardware> hardwareList = new Dictionary<string, Hardware>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbCategory.Items.Add("Monitor");
            cmbCategory.Items.Add("Keyboard");
            cmbCategory.Items.Add("Mouse");
            cmbCategory.Items.Add("CPU");
            cmbCategory.Items.Add("Printer");
            cmbCategory.Items.Add("Laptop");

            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add("In Use");
            cmbStatus.Items.Add("Maintenance");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;

            foreach (var item in hardwareList.Values)
            {
                progressBar1.Value += 10;

                if (progressBar1.Value > 100)
                {
                    progressBar1.Value = 100;
                }
            }
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = hardwareList.Values.ToList();
        }

        private void txtLocation_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtResultName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSortName_Click(object sender, EventArgs e)
        {
            var sortedList = hardwareList.Values.OrderBy(h => h.Name).ToList();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void btnSortQuantity_Click(object sender, EventArgs e)
        {
            var sortedList = hardwareList.Values.OrderBy(h => h.Quantity).ToList();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string status = cmbFilterStatus.Text;

            var filteredList = hardwareList.Values.Where(h => h.Status == status).ToList();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = filteredList;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string id = txtID.Text;

            if (hardwareList.ContainsKey(id))
            {
                Hardware hw = hardwareList[id];

                txtResultName.Text = hw.Name;
                cmbCategory.Text = hw.Category;
                txtResultBrand.Text = hw.Brand;
                txtResultQuantity.Text = hw.Quantity.ToString();
                cmbStatus.Text = hw.Status;
                txtResultLocation.Text = hw.Location;
            }
            else
            {
                MessageBox.Show("Hardware not found");
            }

        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
            }
        }

    }
}
