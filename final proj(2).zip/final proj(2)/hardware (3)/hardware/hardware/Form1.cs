﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;

namespace hardware
{
    public partial class Form1 : Form
    {
        class Items
        {
            public int Id { get; set; }
            public string Code { get; set; }
            public string Name { get; set; }
            public string Category { get; set; }
            public int Quantity { get; set; }
            public string ImagePath { get; set; }
        }

        Dictionary<int, Items> items = new Dictionary<int, Items>();
        string currentImagePath = "";

        public Form1()
        {
            InitializeComponent();
            LoadGrid();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e) { LOAD(); }
        private void saveToolStripMenuItem_Click(object sender, EventArgs e) { SAVE(); }
        private void btnLoad_Click(object sender, EventArgs e) { LOAD(); }
        private void btnSave_Click(object sender, EventArgs e) { SAVE(); }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int id, qty;

                if (!int.TryParse(txtId.Text, out id) || !int.TryParse(txtQuantity.Text, out qty))
                {
                    MessageBox.Show("Please enter numeric values for ID and Quantity.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (items.ContainsKey(id))
                {
                    MessageBox.Show("ID already exists!", "Duplicate ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrEmpty(currentImagePath))
                {
                    MessageBox.Show("Please upload an image before adding item.", "No Image", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                items.Add(id, new Items()
                {
                    Id = id,
                    Code = txtCode.Text,
                    Name = txtName.Text,
                    Category = txtCategory.Text,
                    Quantity = qty,
                    ImagePath = currentImagePath
                });

                LoadGrid();
                ClearInputs();

                pictureBox1.Image = null;
                currentImagePath = "";

                MessageBox.Show("Item added successfully!", "Add Item", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding item: ");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int id, qty;

                if (!int.TryParse(txtId.Text, out id) || !int.TryParse(txtQuantity.Text, out qty))
                {
                    MessageBox.Show("Please enter numeric values for ID and Quantity.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!items.ContainsKey(id))
                {
                    MessageBox.Show("ID not found!", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                items[id].Code = txtCode.Text;
                items[id].Name = txtName.Text;
                items[id].Category = txtCategory.Text;
                items[id].Quantity = qty;
                items[id].ImagePath = currentImagePath;

                LoadGrid();
                ClearInputs();
                pictureBox1.Image = null;

                MessageBox.Show("Item updated successfully!", "Update Item", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating item: ");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int id;

                if (!int.TryParse(txtId.Text, out id))
                {
                    MessageBox.Show("Please enter numeric ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (items.Remove(id))
                {
                    MessageBox.Show("Item deleted successfully!", "Delete Item", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("ID not found!", "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                LoadGrid();
                ClearInputs();
                pictureBox1.Image = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting item: ");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string keyword = txtSearch.Text.ToLower();
                List<Items> result = new List<Items>();

                foreach (Items t in items.Values)
                {
                    if (t.Name.ToLower().Contains(keyword) || t.Code.ToLower().Contains(keyword))
                        result.Add(t);
                }

                dataGridView1.DataSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching: ");
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            try
            {
                string cat = txtFilter.Text.ToLower();
                List<Items> result = new List<Items>();

                foreach (Items t in items.Values)
                {
                    if (t.Category.ToLower().Contains(cat))
                        result.Add(t);
                }

                dataGridView1.DataSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error filtering: ");
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            try
            {
                List<Items> sorted = new List<Items>(items.Values);
                sorted.Sort((a, b) => a.Name.CompareTo(b.Name));
                dataGridView1.DataSource = sorted;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sorting: ");
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    var row = dataGridView1.Rows[e.RowIndex];

                    int id = Convert.ToInt32(row.Cells["Id"].Value);

                    txtId.Text = row.Cells["Id"].Value.ToString();
                    txtCode.Text = row.Cells["Code"].Value.ToString();
                    txtName.Text = row.Cells["Name"].Value.ToString();
                    txtCategory.Text = row.Cells["Category"].Value.ToString();
                    txtQuantity.Text = row.Cells["Quantity"].Value.ToString();

                    if (items.ContainsKey(id))
                    {
                        string path = items[id].ImagePath;

                        if (!string.IsNullOrEmpty(path) && File.Exists(path))
                        {
                            pictureBox1.ImageLocation = path;
                            currentImagePath = path;
                        }
                        else
                        {
                            pictureBox1.Image = null;
                            currentImagePath = "";

                            MessageBox.Show("Image file not found.", "Preview Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error selecting row: ");
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog of = new OpenFileDialog();
                of.Filter = "Images|*.png;*.jpg;*.jpeg";

                if (of.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Enabled = false;
                    progressBar1.Value = 0;

                    string file = of.FileName;

                    for (int i = 0; i <= 100; i++)
                    {
                        progressBar1.Value = i;
                        System.Threading.Thread.Sleep(10);
                        Application.DoEvents();
                    }

                    pictureBox1.ImageLocation = file;
                    currentImagePath = file;

                    pictureBox1.Enabled = true;
                    progressBar1.Value = 0;

                    MessageBox.Show("Image uploaded successfully!", "Upload Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error uploading image: ");
            }
        }

        private void LOAD()
        {
            try
            {
                if (!File.Exists("items.txt"))
                {
                    MessageBox.Show("No saved file found.", "Load Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                items.Clear();

                foreach (string line in File.ReadAllLines("items.txt"))
                {
                    string[] p = line.Split('|');

                    items[int.Parse(p[0])] = new Items()
                    {
                        Id = int.Parse(p[0]),
                        Code = p[1],
                        Name = p[2],
                        Category = p[3],
                        Quantity = int.Parse(p[4]),
                        ImagePath = p.Length > 5 ? p[5] : ""
                    };
                }

                LoadGrid();

                MessageBox.Show("Items loaded successfully!", "Load Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading file: ");
            }
        }

        private void SAVE()
        {
            try
            {
                StreamWriter sw = new StreamWriter("items.txt");

                foreach (var t in items.Values)
                {
                    sw.WriteLine(t.Id + "|" + t.Code + "|" + t.Name + "|" + t.Category + "|" + t.Quantity + "|" + t.ImagePath);
                }

                sw.Close();

                MessageBox.Show("Items saved successfully!", "Save Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving file: ");
            }
        }

        void LoadGrid()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = new List<Items>(items.Values);
        }

        void ClearInputs()
        {
            txtId.Clear();
            txtCode.Clear();
            txtName.Clear();
            txtCategory.Clear();
            txtQuantity.Clear();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
